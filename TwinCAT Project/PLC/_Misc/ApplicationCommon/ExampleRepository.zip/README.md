# Project Name

> Provided under the [Software License Agreement for Beckhoff Software Products](https://www.beckhoff.com/en-en/general-terms-and-conditions/)  
> Copyright (c) 2022 [Beckhoff Automation GmbH & Co. KG](https://www.beckhoff.com)  

## General Info

Write down the general informations of your project. It is worth to always put a project status in the Readme file. This is where you can add it. 

## Technologies

A list of technologies used within the project:
* [Technologie name](https://example.com): Version 12.3 
* [Technologie name](https://example.com): Version 2.34
* [Library name](https://example.com): Version 1234
* V-0.0.0.1 HMI: Version 1.12.1742.03
* V-1.0.0.292 HMI: Version 1.12.1750.01

## License

- [License](./LICENSE.md)
- [Additional License Information](./Legal/AdditionalLicenseInformation.md)

**Free Software**

[comment]: <> (+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++)
[comment]: <> (                                  optional                                   )
[comment]: <> (+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++)

## Installation 

A little intro about the installation. 
```
$ git clone https://example.com
$ cd ../path/to/the/file
$ npm install
$ npm start
```
Side information: To use the application in a special environment use ```lorem ipsum``` to start

## FAQs

A list of frequently asked questions
1. **This is a question in bold**
Answer of the first question with _italic words_. 
2. __Second question in bold__ 
To answer this question we use an unordered list:
   * First point
   * Second Point
   * Third point
3. **Third question in bold**
Answer of the third question with *italic words*.
